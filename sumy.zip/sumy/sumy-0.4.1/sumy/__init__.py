# -*- coding: utf8 -*-

from __future__ import absolute_import
from __future__ import division, print_function, unicode_literals


__author__ = "Michal Belica"
__version__ = "0.4.1"
